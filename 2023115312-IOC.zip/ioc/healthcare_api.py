"""
Mock Healthcare API Functions
These simulate real healthcare APIs with FHIR-style schemas
"""
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from pydantic import BaseModel, Field, validator
import json
import random


# FHIR-style Data Models
class Patient(BaseModel):
    """Patient information following FHIR Patient resource structure"""
    patient_id: str = Field(..., description="Unique patient identifier")
    name: str = Field(..., description="Patient full name")
    date_of_birth: str = Field(..., description="Date of birth in YYYY-MM-DD format")
    gender: str = Field(..., description="Gender: male, female, other")
    phone: Optional[str] = None
    address: Optional[str] = None

    class Config:
        json_schema_extra = {
            "example": {
                "patient_id": "P12345",
                "name": "Ravi Kumar",
                "date_of_birth": "1985-06-15",
                "gender": "male",
                "phone": "+91-9876543210",
                "address": "123 Main St, Mumbai, India"
            }
        }


class InsuranceEligibility(BaseModel):
    """Insurance eligibility information"""
    patient_id: str
    insurance_provider: str
    policy_number: str
    coverage_status: str = Field(..., description="active, expired, pending")
    coverage_type: str = Field(..., description="primary, secondary")
    effective_date: str
    expiry_date: str
    deductible: float
    copay_amount: float

    class Config:
        json_schema_extra = {
            "example": {
                "patient_id": "P12345",
                "insurance_provider": "HealthCare Plus",
                "policy_number": "POL-2024-001",
                "coverage_status": "active",
                "coverage_type": "primary",
                "effective_date": "2024-01-01",
                "expiry_date": "2024-12-31",
                "deductible": 500.0,
                "copay_amount": 25.0
            }
        }


class AppointmentSlot(BaseModel):
    """Available appointment slot"""
    slot_id: str
    provider_id: str
    provider_name: str
    department: str
    date: str
    time: str
    duration_minutes: int = 30

    class Config:
        json_schema_extra = {
            "example": {
                "slot_id": "SLOT-001",
                "provider_id": "DOC-001",
                "provider_name": "Dr. Priya Sharma",
                "department": "Cardiology",
                "date": "2024-01-15",
                "time": "10:00",
                "duration_minutes": 30
            }
        }


class Appointment(BaseModel):
    """Booked appointment information"""
    appointment_id: str
    patient_id: str
    patient_name: str
    provider_id: str
    provider_name: str
    department: str
    appointment_date: str
    appointment_time: str
    status: str = Field(default="confirmed", description="confirmed, cancelled, completed")
    reason: Optional[str] = None
    created_at: str

    class Config:
        json_schema_extra = {
            "example": {
                "appointment_id": "APT-001",
                "patient_id": "P12345",
                "patient_name": "Ravi Kumar",
                "provider_id": "DOC-001",
                "provider_name": "Dr. Priya Sharma",
                "department": "Cardiology",
                "appointment_date": "2024-01-15",
                "appointment_time": "10:00",
                "status": "confirmed",
                "reason": "Follow-up consultation",
                "created_at": "2024-01-10T10:30:00Z"
            }
        }


# Mock Database (In production, this would be a real database)
MOCK_PATIENTS_DB = {
    "P12345": Patient(
        patient_id="P12345",
        name="Ravi Kumar",
        date_of_birth="1985-06-15",
        gender="male",
        phone="+91-9876543210",
        address="123 Main St, Mumbai, India"
    ),
    "P12346": Patient(
        patient_id="P12346",
        name="Anita Desai",
        date_of_birth="1990-03-22",
        gender="female",
        phone="+91-9876543211",
        address="456 Park Ave, Delhi, India"
    )
}

MOCK_INSURANCE_DB = {
    "P12345": InsuranceEligibility(
        patient_id="P12345",
        insurance_provider="HealthCare Plus",
        policy_number="POL-2024-001",
        coverage_status="active",
        coverage_type="primary",
        effective_date="2024-01-01",
        expiry_date="2024-12-31",
        deductible=500.0,
        copay_amount=25.0
    )
}

MOCK_PROVIDERS = [
    {"provider_id": "DOC-001", "name": "Dr. Priya Sharma", "department": "Cardiology"},
    {"provider_id": "DOC-002", "name": "Dr. Rajesh Patel", "department": "Cardiology"},
    {"provider_id": "DOC-003", "name": "Dr. Meera Singh", "department": "Orthopedics"},
]


def search_patient(name: str) -> Dict[str, Any]:
    """
    Search for a patient by name
    
    Args:
        name: Patient's full name or partial name
        
    Returns:
        Dictionary containing patient information or error
    """
    name_lower = name.lower()
    matching_patients = []
    
    for patient_id, patient in MOCK_PATIENTS_DB.items():
        if name_lower in patient.name.lower():
            matching_patients.append(patient.model_dump())
    
    if not matching_patients:
        return {
            "status": "not_found",
            "message": f"No patient found with name containing '{name}'",
            "patients": []
        }
    
    return {
        "status": "success",
        "count": len(matching_patients),
        "patients": matching_patients
    }


def check_insurance_eligibility(patient_id: str) -> Dict[str, Any]:
    """
    Check insurance eligibility for a patient
    
    Args:
        patient_id: Unique patient identifier
        
    Returns:
        Dictionary containing insurance eligibility information
    """
    if patient_id not in MOCK_PATIENTS_DB:
        return {
            "status": "error",
            "message": f"Patient {patient_id} not found",
            "eligibility": None
        }
    
    if patient_id in MOCK_INSURANCE_DB:
        eligibility = MOCK_INSURANCE_DB[patient_id]
        return {
            "status": "success",
            "eligibility": eligibility.model_dump()
        }
    else:
        return {
            "status": "not_found",
            "message": f"No insurance information found for patient {patient_id}",
            "eligibility": None
        }


def find_available_slots(department: str, start_date: Optional[str] = None, 
                        days_ahead: int = 7) -> Dict[str, Any]:
    """
    Find available appointment slots for a department
    
    Args:
        department: Medical department (e.g., "Cardiology", "Orthopedics")
        start_date: Start date in YYYY-MM-DD format (defaults to today)
        days_ahead: Number of days to look ahead (default: 7)
        
    Returns:
        Dictionary containing list of available slots
    """
    if start_date is None:
        start_date = datetime.now().strftime("%Y-%m-%d")
    
    # Filter providers by department
    dept_providers = [p for p in MOCK_PROVIDERS if p["department"].lower() == department.lower()]
    
    if not dept_providers:
        return {
            "status": "error",
            "message": f"No providers found for department: {department}",
            "slots": []
        }
    
    # Generate mock available slots
    slots = []
    base_date = datetime.strptime(start_date, "%Y-%m-%d")
    time_slots = ["09:00", "10:00", "11:00", "14:00", "15:00", "16:00"]
    
    for day in range(days_ahead):
        current_date = base_date + timedelta(days=day)
        # Skip weekends for demo
        if current_date.weekday() >= 5:
            continue
            
        for provider in dept_providers:
            # Randomly make some slots unavailable (70% available)
            if random.random() > 0.3:
                for time in time_slots:
                    slots.append(AppointmentSlot(
                        slot_id=f"SLOT-{len(slots)+1:03d}",
                        provider_id=provider["provider_id"],
                        provider_name=provider["name"],
                        department=department,
                        date=current_date.strftime("%Y-%m-%d"),
                        time=time,
                        duration_minutes=30
                    ).model_dump())
    
    return {
        "status": "success",
        "count": len(slots),
        "slots": slots[:10]  # Limit to 10 slots for demo
    }


def book_appointment(patient_id: str, slot_id: str, reason: Optional[str] = None,
                    dry_run: bool = False) -> Dict[str, Any]:
    """
    Book an appointment for a patient
    
    Args:
        patient_id: Unique patient identifier
        slot_id: Slot identifier from find_available_slots
        reason: Optional reason for the appointment
        dry_run: If True, simulate booking without actually booking
        
    Returns:
        Dictionary containing appointment confirmation or error
    """
    if patient_id not in MOCK_PATIENTS_DB:
        return {
            "status": "error",
            "message": f"Patient {patient_id} not found",
            "appointment": None
        }
    
    patient = MOCK_PATIENTS_DB[patient_id]
    
    # In a real implementation, we would look up the slot from a database
    # For demo, we'll create a mock appointment
    if dry_run:
        return {
            "status": "dry_run",
            "message": "Dry run mode: Appointment would be booked",
            "appointment": {
                "appointment_id": "APT-DRY-RUN",
                "patient_id": patient_id,
                "patient_name": patient.name,
                "slot_id": slot_id,
                "reason": reason,
                "status": "pending_confirmation"
            }
        }
    
    # Create appointment (in real system, this would be persisted)
    appointment = Appointment(
        appointment_id=f"APT-{random.randint(1000, 9999)}",
        patient_id=patient_id,
        patient_name=patient.name,
        provider_id="DOC-001",  # Would come from slot
        provider_name="Dr. Priya Sharma",
        department="Cardiology",
        appointment_date="2024-01-15",  # Would come from slot
        appointment_time="10:00",
        status="confirmed",
        reason=reason,
        created_at=datetime.now().isoformat()
    )
    
    return {
        "status": "success",
        "message": "Appointment booked successfully",
        "appointment": appointment.model_dump()
    }
