"""
Streamlit UI for Clinical Workflow Automation Agent
"""
import streamlit as st
import json
from datetime import datetime
from clinical_agent import ClinicalAgent
from audit_logger import audit_logger
from config import DRY_RUN_MODE

# Page configuration
st.set_page_config(
    page_title="Clinical Workflow Automation Agent",
    page_icon="🏥",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS - Professional Healthcare Interface
st.markdown("""
    <style>
    /* Import Google Fonts for professional typography */
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    /* Main container styling */
    .main .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
        max-width: 1400px;
    }
    
    /* Professional Header */
    .main-header {
        font-family: 'Inter', sans-serif;
        font-size: 2.75rem;
        font-weight: 700;
        background: linear-gradient(135deg, #4a148c 0%, #7b1fa2 50%, #9c27b0 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        margin-bottom: 0.5rem;
        letter-spacing: -0.5px;
    }
    
    .sub-header {
        font-family: 'Inter', sans-serif;
        font-size: 1rem;
        color: #6c757d;
        font-weight: 400;
        margin-bottom: 2rem;
    }
    
    /* Professional Cards */
    .info-card {
        background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
        padding: 1.5rem;
        border-radius: 12px;
        border: 1px solid #e0e0e0;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        margin-bottom: 1.5rem;
        transition: box-shadow 0.3s ease;
    }
    
    .info-card:hover {
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12);
    }
    
    /* Warning Box - Professional */
    .warning-box {
        padding: 1.25rem 1.5rem;
        border-radius: 10px;
        background: linear-gradient(135deg, #fff8e1 0%, #fff3cd 100%);
        border-left: 5px solid #ff9800;
        margin-bottom: 1.5rem;
        box-shadow: 0 2px 6px rgba(255, 152, 0, 0.15);
        font-family: 'Inter', sans-serif;
    }
    
    /* Info Box - Professional */
    .info-box {
        padding: 1.25rem 1.5rem;
        border-radius: 10px;
        background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%);
        border-left: 5px solid #9c27b0;
        margin-bottom: 1.5rem;
        box-shadow: 0 2px 6px rgba(156, 39, 176, 0.15);
        font-family: 'Inter', sans-serif;
    }
    
    /* Success Box - Professional */
    .success-box {
        padding: 1.25rem 1.5rem;
        border-radius: 10px;
        background: linear-gradient(135deg, #e8f5e9 0%, #c8e6c9 100%);
        border-left: 5px solid #4caf50;
        box-shadow: 0 2px 6px rgba(76, 175, 80, 0.15);
        font-family: 'Inter', sans-serif;
        line-height: 1.6;
        color: #1b5e20;
    }
    
    /* Function Call Display */
    .function-call {
        background: linear-gradient(135deg, #f5f5f5 0%, #ffffff 100%);
        padding: 1rem 1.25rem;
        border-radius: 8px;
        margin: 0.75rem 0;
        font-family: 'Courier New', monospace;
        font-size: 0.9rem;
        border: 1px solid #e0e0e0;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.05);
    }
    
    /* Sidebar Styling */
    .css-1d391kg {
        background: linear-gradient(180deg, #f8f9fa 0%, #ffffff 100%);
    }
    
    /* Button Styling */
    .stButton > button {
        font-family: 'Inter', sans-serif;
        font-weight: 500;
        border-radius: 8px;
        transition: all 0.3s ease;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.15);
    }
    
    /* Metric Cards */
    .metric-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        border: 1px solid #e0e0e0;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.08);
    }
    
    /* Section Headers */
    h2, h3 {
        font-family: 'Inter', sans-serif;
        font-weight: 600;
        color: #212529;
        letter-spacing: -0.3px;
    }
    
    /* Footer */
    .footer {
        text-align: center;
        color: #6c757d;
        padding: 2rem 1rem;
        margin-top: 3rem;
        border-top: 1px solid #e0e0e0;
        font-family: 'Inter', sans-serif;
        font-size: 0.9rem;
    }
    
    /* Expander Styling */
    .streamlit-expanderHeader {
        font-family: 'Inter', sans-serif;
        font-weight: 500;
    }
    
    /* Text Input Styling */
    .stTextArea > div > div > textarea {
        font-family: 'Inter', sans-serif;
    }
    
    /* Hide Streamlit branding */
    #MainMenu {visibility: hidden;}
    footer {visibility: hidden;}
    header {visibility: hidden;}
    
    /* Professional gradient background (subtle) */
    .stApp {
        background: linear-gradient(180deg, #ffffff 0%, #f8f9fa 100%);
    }
    
    /* Enhanced Badge/Tag Styling with Highlights */
    .badge {
        display: inline-block;
        padding: 0.5em 0.9em;
        font-size: 0.85em;
        font-weight: 700;
        line-height: 1.2;
        text-align: center;
        white-space: nowrap;
        vertical-align: baseline;
        border-radius: 20px;
        font-family: 'Inter', sans-serif;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
        border: 2px solid rgba(255, 255, 255, 0.3);
        transition: all 0.3s ease;
    }
    
    .badge:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
    }
    
    .badge-success {
        background: linear-gradient(135deg, #4caf50 0%, #66bb6a 100%);
        color: white;
        border-color: rgba(255, 255, 255, 0.4);
    }
    
    .badge-warning {
        background: linear-gradient(135deg, #ff9800 0%, #ffb74d 100%);
        color: white;
        border-color: rgba(255, 255, 255, 0.4);
    }
    
    .badge-info {
        background: linear-gradient(135deg, #2196f3 0%, #64b5f6 100%);
        color: white;
        border-color: rgba(255, 255, 255, 0.4);
    }
    
    .badge-danger {
        background: linear-gradient(135deg, #f44336 0%, #e57373 100%);
        color: white;
        border-color: rgba(255, 255, 255, 0.4);
    }
    
    /* Style expander headers for Agent Interaction entries (red) */
    .stExpander summary:has-text("🔴") {
        color: #d32f2f !important;
        font-weight: 600 !important;
    }
    
    /* Alternative: Target expanders with red border wrapper */
    div[style*="#d32f2f"] .stExpander summary {
        color: #d32f2f !important;
        font-weight: 600 !important;
    }
    
    .badge-primary {
        background: linear-gradient(135deg, #0056b3 0%, #007bff 100%);
        color: white;
        border-color: rgba(255, 255, 255, 0.4);
    }
    
    .badge-secondary {
        background: linear-gradient(135deg, #6c757d 0%, #9e9e9e 100%);
        color: white;
        border-color: rgba(255, 255, 255, 0.4);
    }
    
    .badge-brown {
        background: linear-gradient(135deg, #8d6e63 0%, #a1887f 100%);
        color: white;
        border-color: rgba(255, 255, 255, 0.4);
    }
    
    /* Tag highlight animation */
    @keyframes tagPulse {
        0%, 100% { box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2); }
        50% { box-shadow: 0 2px 12px rgba(0, 0, 0, 0.4); }
    }
    
    .badge-highlight {
        animation: tagPulse 2s ease-in-out infinite;
    }
    
    /* Tag container for inline display */
    .tag-container {
        display: inline-flex;
        gap: 0.5rem;
        flex-wrap: wrap;
        margin: 0.5rem 0;
    }
    </style>
""", unsafe_allow_html=True)

# Initialize session state
if "agent" not in st.session_state:
    st.session_state.agent = ClinicalAgent(dry_run=DRY_RUN_MODE)
if "conversation_history" not in st.session_state:
    st.session_state.conversation_history = []
if "dry_run_mode" not in st.session_state:
    st.session_state.dry_run_mode = DRY_RUN_MODE

# Professional Header
st.markdown("""
    <div style="padding-bottom: 1rem; border-bottom: 2px solid #e0e0e0; margin-bottom: 2rem;">
        <div class="main-header">🏥 Clinical Workflow Automation Agent</div>
        <div class="sub-header">Intelligent Function-Calling LLM Agent for Healthcare Administration</div>
    </div>
""", unsafe_allow_html=True)

# Sidebar with Professional Styling
with st.sidebar:
    st.markdown("### ⚙️ Configuration")
    
    # Dry run mode toggle
    dry_run = st.toggle("🔒 Dry Run Mode", value=st.session_state.dry_run_mode,
                       help="Enable to simulate actions without actually executing them")
    if dry_run != st.session_state.dry_run_mode:
        st.session_state.dry_run_mode = dry_run
        st.session_state.agent = ClinicalAgent(dry_run=dry_run)
    
    st.markdown("---")
    st.markdown("### 📋 Example Queries")
    st.markdown("<div style='color: #6c757d; font-size: 0.9rem; margin-bottom: 1rem;'>Click any example to use it in the main interface</div>", 
                unsafe_allow_html=True)
    
    example_queries = [
        "Search for patient Ravi Kumar",
        "Schedule a cardiology follow-up for patient Ravi Kumar next week and check insurance eligibility",
        "Find available appointment slots for Cardiology department",
        "Check insurance eligibility for patient P12345",
        "Book an appointment for patient P12345 with slot SLOT-001"
    ]
    
    for i, query in enumerate(example_queries):
        if st.button(f"📌 {query[:50]}...", key=f"example_{i}", use_container_width=True):
            st.session_state.example_query = query
    
    st.markdown("---")
    st.markdown("### 📊 System Status")
    
    # Professional status display
    status_color = "#ff9800" if dry_run else "#4caf50"
    status_text = "🟢 Enabled" if dry_run else "🔴 Disabled"
    st.markdown(f"""
        <div style="background: {'#fff8e1' if dry_run else '#e8f5e9'}; 
                    padding: 1rem; 
                    border-radius: 8px; 
                    border-left: 4px solid {status_color};
                    margin-bottom: 1rem;">
            <strong>Dry Run Mode:</strong> <span style="color: {status_color}; font-weight: 600;">{status_text}</span>
        </div>
    """, unsafe_allow_html=True)
    
    # Audit logs section in sidebar
    st.markdown("---")
    st.markdown("### 📋 Audit Logs")
    logs_count = len(audit_logger.get_recent_logs(limit=100))
    
    # Professional metric display
    st.markdown(f"""
        <div style="background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%);
                    padding: 1.25rem;
                    border-radius: 10px;
                    text-align: center;
                    border: 1px solid #ce93d8;
                    margin-bottom: 1rem;">
            <div style="font-size: 2rem; font-weight: 700; color: #7b1fa2; margin-bottom: 0.25rem;">
                {logs_count}
            </div>
            <div style="font-size: 0.9rem; color: #8e24aa; font-weight: 500;">
                Total Log Entries
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    if st.button("🔄 Refresh Logs", use_container_width=True):
        st.rerun()

# Professional Warning Banner
st.markdown("""
    <div class="warning-box">
        <div style="display: flex; align-items: center; gap: 0.75rem;">
            <span style="font-size: 1.5rem;">⚠️</span>
            <div>
                <strong style="font-size: 1.05rem; color: #e65100;">Important Notice</strong>
                <p style="margin: 0.5rem 0 0 0; color: #5d4037; line-height: 1.6;">
                    This agent is designed exclusively for administrative workflow automation. 
                    It does <strong>NOT</strong> provide medical diagnosis, advice, or treatment recommendations.
                </p>
            </div>
        </div>
    </div>
""", unsafe_allow_html=True)

# Main interface with professional purple styling
st.markdown("""
    <div style='background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%);
                padding: 1.5rem;
                border-radius: 12px;
                margin-bottom: 1.5rem;
                border-left: 5px solid #9c27b0;
                box-shadow: 0 2px 8px rgba(156, 39, 176, 0.2);'>
        <h3 style='color: #7b1fa2; font-family: Inter, sans-serif; font-weight: 600; margin: 0 0 0.75rem 0;'>
            💬 Agent Interface
        </h3>
        <div style='color: #8e24aa; font-size: 0.95rem; line-height: 1.6;'>
            Enter your clinical workflow request below. The agent will automatically determine and execute the appropriate functions.
        </div>
    </div>
""", unsafe_allow_html=True)

# Get example query from session state if available
default_query = st.session_state.get("example_query", "")
if default_query:
    del st.session_state.example_query

# Input form
with st.form("agent_form", clear_on_submit=True):
    user_input = st.text_area(
        "Enter your request:",
        value=default_query,
        height=100,
        placeholder="e.g., Schedule a cardiology follow-up for patient Ravi Kumar next week and check insurance eligibility"
    )
    
    col1, col2 = st.columns([1, 4])
    with col1:
        submit_button = st.form_submit_button("🚀 Submit", use_container_width=True)
    with col2:
        clear_button = st.form_submit_button("🗑️ Clear History", use_container_width=True)

if clear_button:
    st.session_state.conversation_history = []
    st.rerun()

# Process request
if submit_button and user_input:
    with st.spinner("Processing request..."):
        try:
            result = st.session_state.agent.process_request(user_input)
            
            # Add to conversation history
            st.session_state.conversation_history.append({
                "timestamp": datetime.now().isoformat(),
                "user_input": user_input,
                "result": result
            })
            
            # Display result
            if result.get("status") == "refused":
                st.markdown(f"""
                    <div style="padding: 1.5rem; border-radius: 10px; background: linear-gradient(135deg, #ffebee 0%, #ffcdd2 100%); 
                                border-left: 5px solid #f44336; margin: 1rem 0;">
                        <span class="badge badge-danger" style="font-size: 0.9rem;">❌ REQUEST REFUSED</span>
                        <p style="margin-top: 1rem; color: #c62828; font-weight: 500;">{result.get('message')}</p>
                    </div>
                """, unsafe_allow_html=True)
            else:
                st.success("✅ Request Processed Successfully")
                
                # Display response with professional styling
                st.markdown("### 📝 Agent Response")
                response_text = result.get('response', 'No response generated').replace('\n', '<br>')
                dry_run_badge = '<span class="badge badge-warning" style="margin-left: 0.5rem;">DRY RUN</span>' if result.get("dry_run") else ''
                st.markdown(f"""
                    <div class='success-box'>
                        <div style="font-size: 1.05rem; font-weight: 500; margin-bottom: 0.75rem; color: #1b5e20;">
                            <span class="badge badge-success">✓ SUCCESS</span>{dry_run_badge}
                        </div>
                        <div style="line-height: 1.8; color: #2e7d32;">
                            {response_text}
                        </div>
                    </div>
                """, unsafe_allow_html=True)
                
                # Display function calls
                function_calls = result.get("function_calls", [])
                if function_calls:
                    st.markdown("### 🔧 Function Calls Executed")
                    st.markdown(f"""
                        <div style="margin-bottom: 1rem;">
                            <span class="badge badge-primary">{len(function_calls)} FUNCTION{'S' if len(function_calls) > 1 else ''} EXECUTED</span>
                        </div>
                    """, unsafe_allow_html=True)
                    for i, func_call in enumerate(function_calls, 1):
                        func_name = func_call.get("function_name", "unknown")
                        func_args = func_call.get("arguments", {})
                        func_result = func_call.get("result", {})
                        
                        # Determine status badge
                        result_status = func_result.get("status", "unknown")
                        status_badge_class = "badge-success" if result_status == "success" else "badge-warning" if result_status == "dry_run" else "badge-danger"
                        
                        with st.expander(
                            f"{i}. {func_name}",
                            expanded=True
                        ):
                            # Display function name as highlighted badge
                            st.markdown(f"""
                                <div style="margin-bottom: 1rem;">
                                    <span class="badge badge-primary" style="font-size: 1rem;">{func_name.upper()}</span>
                                </div>
                            """, unsafe_allow_html=True)
                            st.markdown("""
                                <div style="margin-bottom: 1rem;">
                                    <span class="badge badge-secondary">Arguments</span>
                                </div>
                            """, unsafe_allow_html=True)
                            st.json(func_args)
                            
                            st.markdown("""
                                <div style="margin: 1rem 0 0.5rem 0;">
                                    <span class="badge badge-secondary">Result</span>
                                    <span class="badge {status_badge_class}" style="margin-left: 0.5rem;">{result_status.upper()}</span>
                                </div>
                            """.format(status_badge_class=status_badge_class, result_status=result_status), unsafe_allow_html=True)
                            st.json(func_result)
                            
                            if func_call.get("dry_run"):
                                st.markdown("""
                                    <div style="margin-top: 1rem;">
                                        <span class="badge badge-warning">⚠️ DRY RUN MODE</span>
                                    </div>
                                """, unsafe_allow_html=True)
                
                # Show dry run notice
                if result.get("dry_run"):
                    st.markdown("""
                        <div style="padding: 1rem; border-radius: 8px; background: linear-gradient(135deg, #fff8e1 0%, #fff3cd 100%); 
                                    border-left: 4px solid #ff9800; margin-top: 1rem;">
                            <span class="badge badge-warning">ℹ️ DRY RUN MODE</span>
                            <span style="margin-left: 0.5rem; color: #e65100;">Actions were simulated but not actually executed.</span>
                        </div>
                    """, unsafe_allow_html=True)
        
        except Exception as e:
            st.error(f"❌ Error: {str(e)}")
            audit_logger.log_error(str(e), {"user_input": user_input})

# Display conversation history with professional styling
if st.session_state.conversation_history:
    st.markdown("---")
    st.markdown("### 📜 Conversation History")
    st.markdown(f"<div style='color: #6c757d; margin-bottom: 1rem;'>Showing {min(5, len(st.session_state.conversation_history))} most recent conversations</div>", 
                unsafe_allow_html=True)
    
    for i, entry in enumerate(reversed(st.session_state.conversation_history[-5:]), 1):
        with st.expander(f"Conversation {len(st.session_state.conversation_history) - i + 1} - {entry['timestamp'][:19]}"):
            st.markdown("**User Input:**")
            st.write(entry["user_input"])
            
            st.markdown("**Agent Response:**")
            st.write(entry["result"].get("response", "No response"))
            
            if entry["result"].get("function_calls"):
                st.markdown("**Functions Called:**")
                for func_call in entry["result"]["function_calls"]:
                    st.code(f"{func_call.get('function_name')}({json.dumps(func_call.get('arguments'))})")

# Audit Logs Section - Professional Display with Purple Theme
st.markdown("---")
st.markdown("""
    <div style='background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%);
                padding: 1.5rem;
                border-radius: 12px;
                margin-bottom: 1.5rem;
                border-left: 5px solid #9c27b0;
                box-shadow: 0 2px 8px rgba(156, 39, 176, 0.2);'>
        <h3 style='color: #7b1fa2; font-family: Inter, sans-serif; font-weight: 600; margin: 0 0 0.75rem 0;'>
            📋 Audit Logs & Compliance Trail
        </h3>
        <div style='color: #8e24aa; font-size: 0.95rem; line-height: 1.6;'>
            <strong style='color: #7b1fa2;'>Compliance & Traceability:</strong> All agent actions, function calls, and interactions are logged for audit purposes.
        </div>
    </div>
""", unsafe_allow_html=True)

# Get and display audit logs
audit_logs = audit_logger.get_recent_logs(limit=20)

if audit_logs:
    st.markdown(f"""
        <div style='background: linear-gradient(135deg, #f3e5f5 0%, #e1bee7 100%);
                    padding: 1.25rem 1.5rem;
                    border-radius: 10px;
                    border-left: 5px solid #9c27b0;
                    border: 2px solid #ce93d8;
                    margin-bottom: 1.5rem;
                    font-family: Inter, sans-serif;
                    box-shadow: 0 2px 8px rgba(156, 39, 176, 0.2);'>
            <div style='color: #7b1fa2; font-weight: 600; font-size: 1.05rem; margin-bottom: 0.5rem;'>
                📊 Log Statistics
            </div>
            <div style='color: #8e24aa; font-size: 0.95rem;'>
                Displaying <strong style='color: #7b1fa2; font-size: 1.1rem;'>{len(audit_logs)}</strong> most recent audit log entries
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    # Filter options
    col1, col2, col3 = st.columns(3)
    with col1:
        filter_type = st.selectbox(
            "Filter by Type",
            ["All", "function_call", "agent_interaction", "error"],
            key="audit_filter"
        )
    with col2:
        st.markdown("""
            <style>
            div[data-testid="stSelectbox"]:has([aria-label*="Number of Logs"]) label {
                color: #d32f2f !important;
                font-weight: 600 !important;
            }
            div[data-testid="stSelectbox"]:has([aria-label*="Number of Logs"]) div {
                color: #c62828 !important;
                font-weight: 600 !important;
            }
            </style>
        """, unsafe_allow_html=True)
        show_limit = st.selectbox(
            "🔴 Number of Logs",
            [10, 20, 50, 100],
            index=1,
            key="audit_limit"
        )
        # Display the selected value in red
        st.markdown(f"""
            <div style='color: #d32f2f; font-weight: 600; font-size: 0.9rem; margin-top: -0.5rem;'>
                Selected: <strong style='font-size: 1.1rem;'>{show_limit}</strong>
            </div>
        """, unsafe_allow_html=True)
    with col3:
        if st.button("🔄 Refresh", use_container_width=True):
            st.rerun()
    
    # Filter logs
    if filter_type != "All":
        audit_logs = [log for log in audit_logs if log.get("action_type") == filter_type]
    
    # Limit display
    audit_logs = audit_logs[:show_limit]
    
    # Display logs in a more readable format
    for idx, log in enumerate(reversed(audit_logs), 1):
        action_type = log.get("action_type", "unknown")
        timestamp = log.get("timestamp", "N/A")
        
        # Color coding based on action type
        if action_type == "error":
            icon = "❌"
            color = "#f8d7da"
            text_color = "#c62828"
        elif action_type == "function_call":
            icon = "🔧"
            color = "#d1ecf1"
            text_color = "#1565c0"
        elif action_type == "agent_interaction":
            icon = "💬"
            color = "#efebe9"  # Changed to light brown background
            text_color = "#212529"  # Changed to black text
        else:
            icon = "ℹ️"
            color = "#fff3cd"
            text_color = "#f57c00"
        
        # Format timestamp for display
        display_time = timestamp[:19] if timestamp != 'N/A' else 'Unknown'
        if display_time != 'Unknown':
            try:
                dt = datetime.fromisoformat(display_time.replace('Z', '+00:00'))
                display_time = dt.strftime('%Y-%m-%d %H:%M:%S')
            except:
                pass
        
        # Create highlighted badge for action type
        badge_class = "badge-info"
        if action_type == "error":
            badge_class = "badge-danger"
        elif action_type == "function_call":
            badge_class = "badge-primary"
        elif action_type == "agent_interaction":
            badge_class = "badge-brown"  # Changed to brown badge
        
        action_type_display = action_type.replace('_', ' ').upper()
        
        # Create expander title - use brown styling for agent_interaction
        expander_title_emoji = "💬" if action_type == "agent_interaction" else icon
        
        # Wrap expander in brown container for agent_interaction
        if action_type == "agent_interaction":
            st.markdown(f"""
                <div style='border-left: 5px solid #8d6e63; 
                            background: linear-gradient(90deg, #efebe9 0%, transparent 100%);
                            padding: 0.5rem 0.75rem;
                            margin-bottom: 0.5rem;
                            border-radius: 6px;'>
            """, unsafe_allow_html=True)
        
        # Simple expander title without HTML (Streamlit doesn't support HTML in expander titles)
        with st.expander(
            f"{expander_title_emoji} {idx}. {action_type.replace('_', ' ').title()} • {display_time}",
            expanded=False
        ):
            # Display highlighted action type badge at the top
            st.markdown(f"""
                <div style="margin-bottom: 1rem;">
                    <span class="badge {badge_class} badge-highlight" style="font-size: 1rem;">{action_type_display}</span>
                </div>
            """, unsafe_allow_html=True)
            # Display timestamp with black text for agent_interaction
            timestamp_style = 'color: #212529;' if action_type == "agent_interaction" else ''
            st.markdown(f"**<span style='{timestamp_style}'>Timestamp:</span>** `{timestamp}`", unsafe_allow_html=True)
            
            action_type_label_style = 'color: #212529;' if action_type == "agent_interaction" else ''
            st.markdown(f"""
                <div style="margin: 1rem 0;">
                    <strong style="margin-right: 0.5rem; {action_type_label_style}">Action Type:</strong>
                    <span class="badge {badge_class} badge-highlight">{action_type.replace('_', ' ').upper()}</span>
                </div>
            """, unsafe_allow_html=True)
            
            # Display details based on action type
            details = log.get("details", {})
            
            if action_type == "function_call":
                st.markdown("**Function Details:**")
                func_name = details.get("function_name", "N/A")
                result_status = details.get("result", {}).get("status", "N/A")
                
                # Status badge
                status_badge_class = "badge-success" if result_status == "success" else "badge-warning" if result_status == "dry_run" else "badge-danger"
                
                st.markdown(f"""
                    <div class="tag-container" style="margin-bottom: 1rem;">
                        <span class="badge badge-primary">{func_name.upper()}</span>
                        <span class="badge {status_badge_class}">{result_status.upper()}</span>
                    </div>
                """, unsafe_allow_html=True)
                
                st.json({
                    "function_name": func_name,
                    "arguments": details.get("arguments", {}),
                    "result_status": result_status
                })
                if details.get("result"):
                    with st.expander("Full Result"):
                        st.json(details.get("result"))
            
            elif action_type == "agent_interaction":
                st.markdown("**<span style='color: #212529;'>Interaction Details:</span>**", unsafe_allow_html=True)
                col_a, col_b = st.columns(2)
                with col_a:
                    st.markdown("**<span style='color: #212529;'>User Input:</span>**", unsafe_allow_html=True)
                    st.text_area("User Input", details.get("user_input", "N/A"), height=100, key=f"user_{idx}", disabled=True, label_visibility="collapsed")
                with col_b:
                    st.markdown("**<span style='color: #212529;'>Agent Response:</span>**", unsafe_allow_html=True)
                    st.text_area("Agent Response", details.get("agent_response", "N/A"), height=100, key=f"response_{idx}", disabled=True, label_visibility="collapsed")
                
                if details.get("function_calls"):
                    st.markdown("**Function Calls:**")
                    for fc_idx, fc in enumerate(details.get("function_calls", []), 1):
                        func_name = fc.get('function_name', 'unknown')
                        st.markdown(f"""
                            <div style="margin: 0.5rem 0;">
                                <span class="badge badge-primary" style="margin-right: 0.5rem;">{func_name.upper()}</span>
                                <code style="background: #f5f5f5; padding: 0.25rem 0.5rem; border-radius: 4px;">{json.dumps(fc.get('arguments', {}))}</code>
                            </div>
                        """, unsafe_allow_html=True)
            
            elif action_type == "error":
                st.error(f"**Error:** {details.get('error_message', 'Unknown error')}")
                st.markdown("**Context:**")
                st.json(details.get("context", {}))
            
            else:
                # Show full details for other types
                st.json(details)
            
            # Show user context if available
            if log.get("user_context"):
                st.markdown("**User Context:**")
                st.code(log.get("user_context"))
            
            # Show full log entry (collapsed)
            with st.expander("📄 View Raw Log Entry"):
                st.json(log)
else:
    st.markdown("""
        <div style='background: linear-gradient(135deg, #f5f5f5 0%, #ffffff 100%); 
                    padding: 2rem; 
                    border-radius: 10px; 
                    border: 2px dashed #e0e0e0;
                    text-align: center;
                    margin: 2rem 0;'>
            <div style='font-size: 3rem; margin-bottom: 1rem;'>📋</div>
            <div style='font-size: 1.1rem; font-weight: 600; color: #495057; margin-bottom: 0.5rem;'>
                No audit logs available yet
            </div>
            <div style='color: #6c757d; margin-bottom: 1.5rem;'>
                Logs will appear here as you interact with the agent
            </div>
            <div style='background: white; padding: 1.5rem; border-radius: 8px; text-align: left; display: inline-block;'>
                <strong style='color: #212529; display: block; margin-bottom: 0.75rem;'>What gets logged:</strong>
                <ul style='color: #6c757d; margin: 0; padding-left: 1.5rem; line-height: 2;'>
                    <li>All function calls with arguments and results</li>
                    <li>Complete agent interactions</li>
                    <li>Errors and exceptions</li>
                    <li>All with timestamps for compliance</li>
                </ul>
            </div>
        </div>
    """, unsafe_allow_html=True)

# Professional Footer
st.markdown("---")
st.markdown("""
    <div class="footer">
        <div style="margin-bottom: 0.5rem; font-weight: 500; color: #495057;">
            Clinical Workflow Automation Agent
        </div>
        <div style="color: #6c757d; font-size: 0.85rem;">
            Function-Calling LLM Agent for Healthcare Administration | Built for Compliance & Auditability
        </div>
        <div style="margin-top: 1rem; color: #adb5bd; font-size: 0.75rem;">
            © 2024 Clinical Workflow Automation System
        </div>
    </div>
""", unsafe_allow_html=True)
