"""
Function definitions for the LLM agent
These define the tools/functions the agent can call
"""
from typing import List, Dict, Any, Optional
from healthcare_api import (
    search_patient,
    check_insurance_eligibility,
    find_available_slots,
    book_appointment
)
from config import DRY_RUN_MODE


def get_agent_functions() -> List[Dict[str, Any]]:
    """
    Returns the list of functions available to the agent
    Each function follows OpenAI function calling format
    """
    return [
        {
            "type": "function",
            "function": {
                "name": "search_patient",
                "description": "Search for a patient by name. Use this when you need to find a patient's information or patient ID.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": "Patient's full name or partial name to search for"
                        }
                    },
                    "required": ["name"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "check_insurance_eligibility",
                "description": "Check if a patient has active insurance coverage and get eligibility details. Use this to verify insurance before booking appointments.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "patient_id": {
                            "type": "string",
                            "description": "Unique patient identifier (e.g., P12345)"
                        }
                    },
                    "required": ["patient_id"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "find_available_slots",
                "description": "Find available appointment slots for a medical department. Use this to find appointment availability before booking.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "department": {
                            "type": "string",
                            "description": "Medical department name (e.g., Cardiology, Orthopedics, General Medicine)"
                        },
                        "start_date": {
                            "type": "string",
                            "description": "Start date for search in YYYY-MM-DD format (optional, defaults to today)"
                        },
                        "days_ahead": {
                            "type": "integer",
                            "description": "Number of days to look ahead for availability (optional, default: 7)"
                        }
                    },
                    "required": ["department"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "book_appointment",
                "description": "Book an appointment for a patient. Use this after finding a patient and an available slot. Only use this for actual booking requests.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "patient_id": {
                            "type": "string",
                            "description": "Unique patient identifier"
                        },
                        "slot_id": {
                            "type": "string",
                            "description": "Slot identifier from find_available_slots response"
                        },
                        "reason": {
                            "type": "string",
                            "description": "Reason for the appointment (optional)"
                        }
                    },
                    "required": ["patient_id", "slot_id"]
                }
            }
        }
    ]


def execute_function(function_name: str, arguments: Dict[str, Any], dry_run: bool = None) -> Dict[str, Any]:
    """
    Execute a function call from the agent
    
    Args:
        function_name: Name of the function to execute
        arguments: Dictionary of function arguments
        dry_run: Override global dry_run mode (optional)
        
    Returns:
        Dictionary with function execution result
    """
    if dry_run is None:
        dry_run = DRY_RUN_MODE
    
    # Map function names to actual implementations
    function_map = {
        "search_patient": search_patient,
        "check_insurance_eligibility": check_insurance_eligibility,
        "find_available_slots": find_available_slots,
        "book_appointment": lambda **kwargs: book_appointment(**kwargs, dry_run=dry_run)
    }
    
    if function_name not in function_map:
        return {
            "status": "error",
            "message": f"Unknown function: {function_name}"
        }
    
    try:
        # Execute the function
        result = function_map[function_name](**arguments)
        return {
            "status": "success",
            "function_name": function_name,
            "arguments": arguments,
            "result": result,
            "dry_run": dry_run
        }
    except Exception as e:
        return {
            "status": "error",
            "function_name": function_name,
            "arguments": arguments,
            "error": str(e),
            "dry_run": dry_run
        }
